/* global Phaser, score, topScore, FB */


Cooking = Cooking || {};

Cooking.EndGame = function () {};

Cooking.EndGame.prototype = 
{
    preload : function ()
    {
        this.add.image(0,0,"endgame");
        this.mutebtn = this.add.button(1450,50,'mutebutton',this.muteAudio,this);
        this.applause = this.game.add.audio('Applause');
    },
    
    create : function ()
    {
        var restartBtn = this.add.button(1400, 830, 'restartbutton', this.startRestart, this, 1, 0, 1);
        restartBtn.anchor.set(0.5);
        //howtobtn.scale.x = -1;
        restartBtn.scale.x = 0.2;
        restartBtn.scale.y = 0.2;
        this.add.tween(restartBtn.scale).to({x:1, y:1},1500,Phaser.Easing.Elastic.Out,true);       
        this.add.tween(restartBtn).from( { alpha:0 }, 2000, Phaser.Easing.Bounce.Out, true); 
         var restartBtn = this.add.button(1150, 830, 'sharebutton', this.shareFacebook, this, 1, 0, 1);
        restartBtn.anchor.set(0.5);
        //howtobtn.scale.x = -1;
        restartBtn.scale.x = 0.2;
        restartBtn.scale.y = 0.2;
        this.add.tween(restartBtn.scale).to({x:1, y:1},1500,Phaser.Easing.Elastic.Out,true);       
        this.add.tween(restartBtn).from( { alpha:0 }, 2000, Phaser.Easing.Bounce.Out, true); 
        console.log("Score : "+ this.game.finalTotal);        
        this.finalScoreText = this.add.text(this.world.centerX,525,"$" + this.game.finalTotal,{font:"120px milkshake",align:"center", fill:"#ffffff"});
        this.applause.play();
        this.finalScoreText.anchor.set(0.5);
        this.finalScoreText.bringToTop();
        this.finalScoreText.scale.x = 0.2;
        this.finalScoreText.scale.y = 0.2;
        this.add.tween(this.finalScoreText.scale).to({x:1, y:1},1500,Phaser.Easing.Elastic.Out,true); 
        
         /* make the API call */
        var FBscore = this.score;
        var newTopScore = false;
        if (FBscore > topScore) {
            newTopScore = true;
            FB.login(function (response) {
                FB.api(
                        "/me/scores",
                        "POST",
                        {
                            "score": FBscore
                        }
                );
            }, {scope: 'publish_actions'});
        }
    }, 
    
    shareFacebook : function () {
        console.log("sharing in facebook");
        FB.ui({
            method: 'share_open_graph',
            action_type: 'og.likes',
            action_properties: JSON.stringify({
              object:'https://developers.facebook.com/docs/',
            })
          }, function(response){
            // Debug response (optional)
            console.log(response);
});
        
    },
    
    muteAudio : function ()
    {
        
        if (!this.game.sound.mute) 
        {
            this.mutebtn.frame = 1;
        } 
        else 
        {
            this.mutebtn.frame = 0;
        }        
        this.game.sound.mute =! this.game.sound.mute;  
    },
    
    startRestart : function ()
    {   
        this.game.buttonAudio.play();
        this.state.start("MainMenu");       
    }    
    
};