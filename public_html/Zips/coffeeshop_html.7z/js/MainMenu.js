/* global Phaser */

Cooking = Cooking || {};

Cooking.MainMenu = function () {};

Cooking.MainMenu.prototype = 
{
    preload : function ()
    {
        this.add.image(0,0,"CoffeeShop_Background");
    },
    
   create : function ()
    {
        
        var playBtn = this.add.button(400, 830, 'playbutton', this.startPlay, this, 1, 0, 1);
        playBtn.anchor.set(0.5);
        this.add.tween(playBtn).from( { y: -200 }, 2000, Phaser.Easing.Bounce.Out, true);
        
        var ingrediantsbtn = this.add.button(800, 830, 'ingredientsbutton', this.startIngredients, this, 2, 0, 1);
        ingrediantsbtn.anchor.set(0.5);
        this.add.tween(ingrediantsbtn).from( { y: -200 }, 2000, Phaser.Easing.Bounce.Out, true);
        
        var howtobtn = this.add.button(1200, 830, 'howtobutton', this.startHowTo, this, 1, 0, 1);
        howtobtn.anchor.set(0.5);
        this.add.tween(howtobtn).from( { y: -200 }, 2000, Phaser.Easing.Bounce.Out, true);
    },    
    
    startPlay : function ()
    {
       this.state.start("Play");  
    },
    
    startIngredients : function ()
    {
       this.state.start("Ingredients");  
    },
    
    startHowTo : function ()
    {
       this.state.start("Howto");  
    }
    

};


