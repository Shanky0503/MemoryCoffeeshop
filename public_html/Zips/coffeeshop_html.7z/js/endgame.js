/* global Phaser, score */


Cooking = Cooking || {};

Cooking.EndGame = function () {};

Cooking.EndGame.prototype = 
{
    preload : function ()
    {
        this.add.image(0,0,"endgame");
    },
    
   create : function ()
    {
        var restartBtn = this.add.button(1400, 830, 'restartbutton', this.startRestart, this, 1, 0, 1);
        restartBtn.anchor.set(0.5);
        //howtobtn.scale.x = -1;
        restartBtn.scale.x = 0.2;
        restartBtn.scale.y = 0.2;
        this.add.tween(restartBtn.scale).to({x:1, y:1},1500,Phaser.Easing.Elastic.Out,true);       
        this.add.tween(restartBtn).from( { alpha:0 }, 2000, Phaser.Easing.Bounce.Out, true); 
        console.log("Score : "+ this.game.finalTotal);        
        this.finalScoreText = this.add.text(this.world.centerX,525,"$" + this.game.finalTotal,{font:"120px milkshake",align:"center", fill:"#ffffff"});
        this.finalScoreText.anchor.set(0.5);
        this.finalScoreText.bringToTop();
        this.finalScoreText.scale.x = 0.2;
        this.finalScoreText.scale.y = 0.2;
        this.add.tween(this.finalScoreText.scale).to({x:1, y:1},1500,Phaser.Easing.Elastic.Out,true);
        
                
    },    
    
    startRestart : function ()
    {   
        this.state.start("MainMenu");       
    },
    
    render : function () 
    {
        //this.game.debug.inputInfo(32,32);
    }

};